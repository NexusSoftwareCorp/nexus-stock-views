
# Nexus Stock View (Web-Version)

Dies ist die Web-App-Version für die NSC-Aktie von Nexus Software Corp.

## Funktionen
- Login mit 20-stelligem Code
- Code-Generator
- Goldschwarzes Börsendesign
- App-Logo eingebunden

## Anleitung
1. Lade dieses ZIP aus
2. Lade den Inhalt auf GitHub in ein neues Repository hoch
3. Aktiviere GitHub Pages unter Repository -> Settings -> Pages

Dann ist deine Seite sofort online, z. B. unter:
`https://deinname.github.io/nexus-stock-view/`
